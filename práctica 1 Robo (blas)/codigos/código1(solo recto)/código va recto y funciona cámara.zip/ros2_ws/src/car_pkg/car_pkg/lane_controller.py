#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
import numpy as np
import cv2
from cv_bridge import CvBridge
from sensor_msgs.msg import Image
from std_msgs.msg import Float64

class LaneController(Node):

    def __init__(self):
        super().__init__('lane_controller_node')
        
        # --- Constante de Conversión ---
        self.KMH_TO_MS = 1000.0 / 3600.0  # (1 / 3.6)
        
        # --- Parámetros del Vehículo ---
        self.WHEEL_RADIUS = 0.331  # metros (radio de las ruedas)
        self.WHEEL_DISTANCE = 1.628  # metros (distancia entre ruedas)
        self.MAX_SPEED = 20.0  # rad/s (velocidad máxima angular de las ruedas)
        
        # --- Parámetros del Controlador ---
        self.KP = 0.005  # Ganancia Proporcional
        self.TARGET_SPEED = 30.0  # Velocidad por defecto (km/h)
        self.current_max_speed = self.TARGET_SPEED
        self.stop_mode = False
        self.stop_timer = None

        # --- Herramientas ---
        self.bridge = CvBridge()

        # --- Publicadores para los motores ---
        self.left_motor_pub = self.create_publisher(Float64, '/car/left_wheel', 10)
        self.right_motor_pub = self.create_publisher(Float64, '/car/right_wheel', 10)

        # --- Suscriptores ---
        # 1. Suscriptor a la cámara de carril (road_camera)
        self.subscription_camera = self.create_subscription(
            Image,
            '/car/road_camera/image_raw',
            self.camera_callback,
            10)
        
        # 2. Suscriptor al nodo de señales para saber la velocidad
        self.subscription_speed = self.create_subscription(
            Float64,
            '/car/max_speed',
            self.speed_callback,
            10)
        
        self.get_logger().info('Nodo "lane_controller" iniciado.')

    def speed_callback(self, msg):
        """Callback que se activa cuando el detector de señales envía una nueva velocidad."""
        new_speed = msg.data
        
        if new_speed == 0.0:
            # Lógica de STOP: Poner en modo 'stop' y guardar la velocidad anterior
            if not self.stop_mode:
                self.get_logger().info('¡Recibida orden de STOP!')
                self.current_max_speed = self.TARGET_SPEED
                self.TARGET_SPEED = 0.0
                self.stop_mode = True
                
                # Crear un temporizador para reanudar la marcha después de 1s
                if self.stop_timer:
                    self.stop_timer.cancel()
                self.stop_timer = self.create_timer(1.0, self.resume_from_stop)

        elif self.stop_mode:
            # Si estamos en modo stop, no hacer nada hasta que se reanude
            pass
        else:
            # Actualizar la velocidad máxima
            self.get_logger().info(f'Nueva velocidad máxima: {new_speed} km/h')
            self.TARGET_SPEED = new_speed
            self.current_max_speed = new_speed

    def resume_from_stop(self):
        """Función para reanudar la marcha después de un STOP."""
        self.get_logger().info('Reanudando marcha...')
        self.TARGET_SPEED = self.current_max_speed
        self.stop_mode = False
        if self.stop_timer:
            self.stop_timer.cancel()
            self.stop_timer = None

    def camera_callback(self, msg):
        """Callback principal que procesa la imagen del carril."""
        try:
            # Convertir la imagen de ROS (sensor_msgs/Image) a OpenCV
            cv_image = self.bridge.imgmsg_to_cv2(msg, desired_encoding='bgr8')
        except Exception as e:
            self.get_logger().error(f'Error al convertir imagen: {e}')
            return

        # 1. Procesar la imagen
        # La imagen es 512x16x3. Queremos la media de las columnas.
        mean_vector = np.mean(cv_image, axis=0)  # Vector de 512x3
        line_vector = np.mean(mean_vector, axis=1)  # Vector de 512 valores
        
        # 2. Encontrar el centro del carril
        if np.max(line_vector) < 50:  # Umbral
            centro_carril_detectado = msg.width / 2
        else:
            centro_carril_detectado = np.argmax(line_vector)

        # 3. Calcular el error
        centro_ideal = msg.width / 2
        error = centro_ideal - centro_carril_detectado

        # 4. Calcular el giro (Controlador P)
        angulo_giro = self.KP * error
        
        # 5. Convertir velocidad lineal y angular a velocidades de rueda
        velocidad_en_ms = self.TARGET_SPEED * self.KMH_TO_MS
        
        # Cinemática diferencial
        v = velocidad_en_ms
        omega = angulo_giro
        
        left_speed = (v - omega * self.WHEEL_DISTANCE / 2.0) / self.WHEEL_RADIUS
        right_speed = (v + omega * self.WHEEL_DISTANCE / 2.0) / self.WHEEL_RADIUS
        
        # Limitar velocidades
        left_speed = max(-self.MAX_SPEED, min(self.MAX_SPEED, left_speed))
        right_speed = max(-self.MAX_SPEED, min(self.MAX_SPEED, right_speed))
        
        # 6. Publicar velocidades a los motores
        left_msg = Float64()
        left_msg.data = left_speed
        self.left_motor_pub.publish(left_msg)
        
        right_msg = Float64()
        right_msg.data = right_speed
        self.right_motor_pub.publish(right_msg)


def main(args=None):
    rclpy.init(args=args)
    lane_controller = LaneController()
    rclpy.spin(lane_controller)
    
    lane_controller.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()